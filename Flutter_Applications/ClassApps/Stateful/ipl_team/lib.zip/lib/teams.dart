import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:ipl_team/home.dart';
import 'package:ipl_team/players.dart';

class Teams extends StatefulWidget {
  const Teams({super.key});

  @override
  State<Teams> createState() => _TeamsState();
}

class _TeamsState extends State<Teams> {

  Map franchiseUrl={
    "MI":"assets/png/MI.jpg",
    "CSK":"assets/png/CSK.jpg",
    "DC":"assets/png/DC.jpg",
    "KKR":"assets/png/KKR.jpg",
    "LSG":"assets/png/LSG.png",
    "RCB":"assets/png/RCB.jpg",
    "SRH":"assets/png/SRH.jpg"

  };

  List teamKeys=playerData.keys.toList();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 255, 255, 255),
      appBar: AppBar(
        title: const Text("Teams"),
        centerTitle: true,
        backgroundColor: const Color.fromARGB(255, 238, 51, 51),
      ),

      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: ListView.builder(
          itemCount:playerData.length,
          itemBuilder: (context,index){
            return Padding(
              padding: const EdgeInsets.only(bottom: 20),
              child: GestureDetector(
                onTap: (){
                  
                  String team=teamKeys[index];
                  
                 Navigator.of(context).push(MaterialPageRoute(builder: (context)=>Players(team: team,)));
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: Color.fromARGB(255, 251, 181, 131)
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                        height: 80,
                        width: 80,
                      
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle
                        ),
                
                        child: Image.asset("${franchiseUrl[teamKeys[index]]}",fit: BoxFit.cover,),
                      ),
                      Text("${teamKeys[index]}")
                    ],
                  ),
                ),
              ),
            );
        }),
      ),
    );
  }
}