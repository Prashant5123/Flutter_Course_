import 'dart:io';

import 'package:flutter/material.dart';
import 'package:ipl_team/home.dart';

class Players extends StatefulWidget {
  String team;
   Players( {super.key,required this.team});

  @override
  State<Players> createState() => _PlayersState();
}

class _PlayersState extends State<Players> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 255, 255, 255),
      appBar: AppBar(
        title: const Text("Players"),
        centerTitle: true,
        backgroundColor: const Color.fromARGB(255, 238, 51, 51),
      ),

      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: ListView.builder(
          itemCount:playerData[widget.team].length,
          itemBuilder: (context,index){
            return Padding(
              padding: const EdgeInsets.only(bottom: 20),
              child: Container(
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 251, 181, 131)
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Container(
                      height: 80,
                      width: 80,
                    
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle
                      ),
              
                      child: Image.network("${playerData[widget.team][index]["url"]}",fit: BoxFit.cover,),),
                    
                    Column(
                      children: [
                        Text("${playerData[widget.team][index]["name"]}"),

                         Text("${playerData[widget.team][index]["jerNum"]}"),

                          Text("${playerData[widget.team][index]["team"]}"),

                      ],
                    )
                  ],
                ),
              ),
            );
        }),
      ),
    );
  }
}